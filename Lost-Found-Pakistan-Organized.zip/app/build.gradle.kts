plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "pk.lostfound.pakistan"
    compileSdk = 35
    defaultConfig {
        applicationId = "pk.lostfound.pakistan"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        buildConfigField("String", "FIREBASE_API_KEY", "\"${providers.gradleProperty("FIREBASE_API_KEY").orNull ?: ""}\"")
        buildConfigField("String", "FIREBASE_APP_ID", "\"${providers.gradleProperty("FIREBASE_APP_ID").orNull ?: ""}\"")
        buildConfigField("String", "FIREBASE_PROJECT_ID", "\"${providers.gradleProperty("FIREBASE_PROJECT_ID").orNull ?: ""}\"")
        buildConfigField("String", "FIREBASE_SENDER_ID", "\"${providers.gradleProperty("FIREBASE_SENDER_ID").orNull ?: ""}\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("com.google.firebase:firebase-functions")
    implementation("com.google.firebase:firebase-app-check")
    implementation("com.google.firebase:firebase-app-check-playintegrity")
    debugImplementation("com.google.firebase:firebase-app-check-debug")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
